#!/usr/bin/env python3
from math import inf
from fishing_game_core.game_tree import Node
from fishing_game_core.player_utils import PlayerController
from fishing_game_core.shared import ACTION_TO_STR
from time import time
from copy import deepcopy



class PlayerControllerHuman(PlayerController):
    def player_loop(self):
        """
        Function that generates the loop of the game. In each iteration
        the human plays through the keyboard and send
        this to the game through the sender. Then it receives an
        update of the game through receiver, with this it computes the
        next movement.
        :return:
        """

        while True:
            # send message to game that you are ready
            msg = self.receiver()
            if msg["game_over"]:
                return


class PlayerControllerMinimax(PlayerController):

    def __init__(self):
        super(PlayerControllerMinimax, self).__init__()
        self.action=0
        self.hash=dict()
        self.start_time = 0
        self.abort_before_timeout = True
        self.time_left=0


    def player_loop(self):
        """
        Main loop for the minimax next move search.
        :return:
        """

        # Generate first message (Do not remove this line!)
        first_msg = self.receiver()
        ##print(first_msg)
        while True:
            msg = self.receiver()
            # Create the root node of the game tree
            node = Node(message=msg, player=0)
            # Possible next moves: "stay", "left", "right", "up", "down"
            self.start_time = time()
            self.abort_before_timeout = True
            self.hash=dict()
            best_move = self.search_best_next_move(initial_tree_node=node)

            # Execute next action
            self.sender({"action": best_move, "search_time": None})

    

    def search_best_next_move(self, initial_tree_node):
        """
        Use minimax (and extensions) to find best possible next move for player 0 (green boat)
        :param initial_tree_node: Initial game tree node
        :type initial_tree_node: game_tree.Node
            (see the Node class in game_tree.py for more information!)
        :return: either "stay", "left", "right", "up" or "down"
        :rtype: str
        """

        # EDIT THIS METHOD TO RETURN BEST NEXT POSSIBLE MODE USING MINIMAX ###

        # NOTE: Don't forget to initialize the children of the current node
        #       with its compute_and_get_children() method!
        
        #try to create the search tree
        depthmax=8
        alpha=-1e5
        beta=1e5
        self.action=0
        initial_tree_node.heuristic_score = self.heuristic(initial_tree_node)
        #for depthmax in range(9):
        self.alphabeta(initial_tree_node,depthmax,alpha,beta)

        #print('action')
        #print(self.action)
        return ACTION_TO_STR[self.action]
    
    def distance(self,hook,fish):
        y = abs(fish[1] - hook[1])
        x = min(20-abs(fish[0] - hook[0]),abs(fish[0] - hook[0]))
        distance = x + y
        return distance 

    def heuristic(self,node):
        hooks_pos = deepcopy(node.state.hook_positions)
        fish_scores = node.state.fish_scores
        v = 0
        caught = node.state.get_caught()[0]
        if caught :
            v += 0.5*fish_scores[caught]
        for fish, pos in node.state.fish_positions.items():
            this_fish = fish_scores[fish]
            d_0 = self.distance(hooks_pos[0],pos)
            d_1 = self.distance(hooks_pos[1],pos)
            if this_fish < 0:
                d_0 = max(-1,-d_0)
                d_1 = max(-1,-d_1)
                this_fish = max(-1,this_fish)
            f = 4*d_1 - 2*d_0 + pos[1]+this_fish 
            v += f 
        g = node.state.player_scores[0] - node.state.player_scores[1]
        heuristic_score =0.0001*v + g 
        return heuristic_score 
       
   
    
   
   
    def alphabeta(self,node,depth,alpha,beta):
        myhash= hash(
            (
                hash(frozenset(node.state.hook_positions.items())),
                hash(frozenset(node.state.fish_positions.items())),
            )
        )
        if myhash in self.hash:
            return self.hash[myhash]
        self.time_left = 75e-3 - (time() - self.start_time)
        children = node.compute_and_get_children()
        if (len(children) == 1 and children[0].move == 1) or depth==0 or len(children) == 0 or self.time_left < 0.028:#(self.time_buffer + 0.002*1.8**depth):
            self.hash[myhash] = node.heuristic_score #score 
            return node.heuristic_score
        for child in children:
            child.heuristic_score = self.heuristic(child)
        if node.state.player==0:
            v=-1e5
            children = list(sorted(children, key=lambda c: c.heuristic_score, reverse=True))
            for child in children:
                temp=alpha
                v=max(v,self.alphabeta(child,depth-1,alpha,beta))
                           
                alpha=max(alpha,v)
                if node.parent==None and alpha!=temp:
                    self.action=child.move                      
                if beta<=alpha:
                    break
        else:
            v=1e5
            children = list(sorted(children, key=lambda c: c.heuristic_score, reverse=False))
            for child in children:
                v=min(v,self.alphabeta(child,depth-1,alpha,beta))
                beta=min(beta,v)
                if beta<=alpha:
                    break
        
        return v
            